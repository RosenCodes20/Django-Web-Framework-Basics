from django.apps import AppConfig


class WorldOfSpeedConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'exam_preparation_1.world_of_speed'
